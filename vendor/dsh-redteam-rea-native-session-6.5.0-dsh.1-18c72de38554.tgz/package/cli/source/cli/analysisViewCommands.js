import { z } from "incur";
import { inspectAnalysisViewValidated } from "../../../upstream/dist/application/analysisView/AnalysisViewService.js";
import { readEvidenceBundle } from "../../../upstream/dist/application/EvidenceBundleFiles.js";
import { inspectEvidenceBundle } from "../../../upstream/dist/application/investigation/InspectEvidenceBundle.js";
import { getEvidenceBundleInputSchema, importEvidenceBundleInputSchema, } from "../../../upstream/dist/contracts/sessionToolSchemas.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { parseCliJsonInput } from "../cliJsonInput.js";
import { logCliCommand } from "../cliLogging.js";
import { projectAnalysisError } from "../../../upstream/dist/domain/analysisErrorProjection.js";
import { analysisInputErrorFromIssues } from "../../../upstream/dist/domain/inputIssueProjection.js";
import { jsonValueSchema } from "../../../upstream/dist/domain/jsonValue.js";
import { inspectAnalysisViewInputSchema } from "../../../upstream/dist/domain/analysisView/analysisView.js";
/** Project selected views of completed analysis Evidence through the CLI. */
export const registerAnalysisViewCommands = (cli, logger) => {
    cli.command(CLI_COMMANDS.inspectEvidenceBundle, {
        description: "Inspect complete or selected discovery metadata from a local Evidence bundle",
        args: z.object({
            inputJson: z
                .string()
                .describe("JSON or JSON file with absolute path, detail and optional record filters"),
        }),
        run: ({ args }) => logCliCommand(logger, CLI_COMMANDS.inspectEvidenceBundle, async () => {
            const input = await parseCliJsonInput(args.inputJson, CLI_COMMANDS.inspectEvidenceBundle);
            if (!input.ok)
                return input.error;
            const schema = getEvidenceBundleInputSchema.safeExtend({
                path: importEvidenceBundleInputSchema.shape.path,
            });
            const parsed = schema.safeParse(input.value);
            if (!parsed.success)
                return {
                    error: "Evidence bundle inspection failed",
                    ...projectAnalysisError(analysisInputErrorFromIssues(CLI_COMMANDS.inspectEvidenceBundle, parsed.error.issues, input.value)),
                };
            const loaded = await readEvidenceBundle(parsed.data.path);
            if (!loaded.ok)
                return {
                    error: "Evidence bundle inspection failed",
                    ...projectAnalysisError(loaded.error),
                };
            const result = inspectEvidenceBundle(loaded.value, parsed.data);
            return result.ok
                ? result.value
                : {
                    error: "Evidence bundle inspection failed",
                    ...projectAnalysisError(result.error),
                };
        }),
    });
    cli.command(CLI_COMMANDS.inspectAnalysisView, {
        description: "Project a selected view of completed binary-layout, JavaScript application, native function, artifact-inventory, WASM, Mach-O, Interface Builder, EVM, managed, Android package, Dart AOT, web network capture or pcap Evidence JSON",
        args: z.object({
            inputJson: z.string().describe("Inline workflow JSON or JSON file path"),
        }),
        run: ({ args }) => logCliCommand(logger, CLI_COMMANDS.inspectAnalysisView, async () => {
            const input = await parseCliJsonInput(args.inputJson, CLI_COMMANDS.inspectAnalysisView);
            if (!input.ok)
                return input.error;
            const parsed = inspectAnalysisViewInputSchema.safeParse(input.value);
            if (!parsed.success)
                return {
                    error: "Application workflow failed",
                    ...projectAnalysisError(analysisInputErrorFromIssues(CLI_COMMANDS.inspectAnalysisView, parsed.error.issues, input.value)),
                };
            const result = inspectAnalysisViewValidated(parsed.data);
            return result.ok
                ? jsonValueSchema.parse(result.value)
                : {
                    error: "Application workflow failed",
                    ...projectAnalysisError(result.error),
                };
        }),
    });
};
