import { z } from "incur";
import { DOCTOR_PROVIDER_IDS } from "../../../upstream/dist/application/DoctorProviderIds.js";
import { isSetupFailure, } from "../../../upstream/dist/application/SetupTypes.js";
import { isUninstallFailure } from "../../../upstream/dist/application/UninstallFailure.js";
import { homeDirectoryFromEnvironment } from "../../../upstream/dist/config/homeDirectory.js";
import { isUpdateFailure } from "../../../upstream/dist/application/UpdateFailure.js";
import { confirmInteractiveSetup, renderSetupDryRun, renderInteractiveSetupResult, renderSetupProgress, } from "./interactiveSetup.js";
import { PRODUCT_IDENTITY } from "../../../upstream/dist/identity.js";
import { logCliCommand } from "../cliLogging.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { SUPPORTED_CLIENT_DEFINITIONS } from "../../../upstream/dist/application/SupportedClients.js";
const supportedClientIds = SUPPORTED_CLIENT_DEFINITIONS.map(({ name }) => name);
const supportedClientSchema = z
    .string()
    .refine((candidate) => supportedClientIds.some((name) => name === candidate), "Unsupported agent integration");
const skillClientSchema = z.union([z.literal("shared"), supportedClientSchema]);
/** Register setup, doctor, uninstall, and update CLI commands. */
export const registerSetupCommands = (cli, logger, environment) => {
    registerSetupCommand(cli, logger, environment);
    registerDoctorCommand(cli, logger, environment);
    registerMaintenanceCommands(cli, logger, environment);
};
const registerSetupCommand = (cli, logger, environment) => {
    cli.command(CLI_COMMANDS.setup, {
        description: "Configure agent integrations and optional analysis providers",
        outputPolicy: "agent-only",
        options: z.object({
            yes: z
                .boolean()
                .default(false)
                .describe("Approve user-owned setup actions without prompting"),
            installHopper: z
                .boolean()
                .default(false)
                .describe("Also approve Hopper installation with --yes"),
            client: z
                .array(supportedClientSchema)
                .default([])
                .describe("Agent integration to configure; repeat for multiple agents"),
            skillClient: z
                .array(skillClientSchema)
                .default([])
                .describe("Existing client skill destination to update; repeatable"),
            allDetected: z
                .boolean()
                .default(false)
                .describe("Configure every detected supported agent"),
            skill: z
                .boolean()
                .optional()
                .describe("Override the bundled skill included with agent integrations"),
            dryRun: z
                .boolean()
                .default(false)
                .describe("Print the resolved plan without applying it"),
            accessible: z
                .boolean()
                .default(false)
                .describe("Use sequential accessible setup prompts"),
        }),
        alias: { yes: "y" },
        run: ({ options, formatExplicit }) => logCliCommand(logger, CLI_COMMANDS.setup, () => runSetupCommand({ options, formatExplicit }, environment), isSetupFailure),
    });
};
const registerDoctorCommand = (cli, logger, environment) => {
    cli.command(CLI_COMMANDS.doctor, {
        description: "Check whether REA is ready",
        options: z.object({
            target: z.string().optional().describe("Optional app path to check"),
            client: z
                .array(supportedClientSchema)
                .default([])
                .describe("Agent registration whose readiness is required; repeatable"),
            provider: z
                .array(z.enum(DOCTOR_PROVIDER_IDS))
                .default([])
                .describe("Deep-analysis provider whose readiness is required"),
            skill: z
                .boolean()
                .optional()
                .describe("Require the installed REA skill identity to be aligned"),
        }),
        run: ({ options }) => logCliCommand(logger, "doctor", async () => {
            const [{ runDoctorOwned }, { createSystemDoctorHost }] = await Promise.all([
                import("../../../upstream/dist/application/Doctor.js"),
                import("../../../upstream/dist/doctorRuntime.js"),
            ]);
            return runDoctorOwned(options.target, createSystemDoctorHost(environment), doctorScope(options));
        }),
    });
};
const registerMaintenanceCommands = (cli, logger, environment) => {
    cli.command(CLI_COMMANDS.uninstall, {
        description: "Remove REA-owned agent configuration and skill files",
        options: z.object({
            purgeData: z
                .boolean()
                .default(false)
                .describe("Also remove REA caches and state"),
        }),
        run: ({ options }) => logCliCommand(logger, "uninstall", async () => {
            const { runUninstall, systemUninstallHost } = await import("../../../upstream/dist/application/Uninstall.js");
            return runUninstall(options.purgeData, systemUninstallHost(homeDirectoryFromEnvironment(environment, process.platform), undefined, environment));
        }, isUninstallFailure),
    });
    cli.command(CLI_COMMANDS.update, {
        description: "Update this REA installation and verify the installed release",
        run: ({ formatExplicit }) => logCliCommand(logger, CLI_COMMANDS.update, async () => {
            const [{ runUpdate }, { systemUpdateHost }] = await Promise.all([
                import("../../../upstream/dist/application/Update.js"),
                import("../../../upstream/dist/application/UpdateRuntime.js"),
            ]);
            return runUpdate(PRODUCT_IDENTITY.packageVersion, systemUpdateHost(undefined, undefined, environment), formatExplicit ? "structured" : "human");
        }, isUpdateFailure),
    });
};
const runSetupCommand = async (input, environment) => {
    const { options } = input;
    const interactive = setupIsInteractive(options, input.formatExplicit);
    const hasExplicitScope = setupHasExplicitScope(options);
    const [{ runSetup }, { systemSetupHost }, { createSystemDoctorHost }] = await Promise.all([
        import("../../../upstream/dist/application/Setup.js"),
        import("../../../upstream/dist/application/SetupHost.js"),
        import("../../../upstream/dist/doctorRuntime.js"),
    ]);
    const result = await runSetup(setupRunOptions(input, interactive, hasExplicitScope), systemSetupHost(createSystemDoctorHost(environment), environment), interactive
        ? (actions, context) => confirmInteractiveSetup(actions, options.accessible, context)
        : undefined);
    if (interactive)
        renderInteractiveSetupResult(result, environment);
    else if (options.dryRun &&
        !input.formatExplicit &&
        hasInteractiveTerminal()) {
        if (result.status === "planned")
            renderSetupDryRun(result.plannedActions);
        else
            renderInteractiveSetupResult(result, environment);
    }
    return result;
};
const setupRunOptions = (input, interactive, hasExplicitScope) => {
    const { options } = input;
    const agentIntegrationSelected = options.allDetected ||
        options.client.length > 0 ||
        options.skillClient.length > 0;
    const hasSelectedClients = hasExplicitScope &&
        !options.allDetected &&
        (options.client.length > 0 || options.skillClient.length > 0);
    return {
        approved: options.yes && !options.dryRun,
        installHopper: options.installHopper,
        structured: input.formatExplicit || options.dryRun,
        dryRun: options.dryRun,
        allDetectedClients: options.allDetected,
        proposeHopper: interactive || options.installHopper,
        ...(hasSelectedClients ? { clientIds: options.client } : {}),
        ...(options.skillClient.length > 0
            ? { skillClientIds: options.skillClient }
            : {}),
        ...(hasExplicitScope
            ? { installSkill: options.skill ?? agentIntegrationSelected }
            : {}),
        ...(interactive ? { onProgress: renderSetupProgress } : {}),
        ...(hasSelectedClients
            ? {
                readinessScope: {
                    clients: options.client,
                    ...(options.skillClient.length > 0
                        ? { skillClients: options.skillClient }
                        : {}),
                    providers: options.installHopper ? ["hopper"] : [],
                    skill: options.skill ?? agentIntegrationSelected,
                },
            }
            : {}),
    };
};
const setupIsInteractive = (options, formatExplicit) => !options.yes &&
    !options.dryRun &&
    !formatExplicit &&
    hasInteractiveTerminal();
const hasInteractiveTerminal = () => process.stdin.isTTY === true &&
    process.stdout.isTTY === true &&
    process.stderr.isTTY === true;
const setupHasExplicitScope = (options) => options.allDetected ||
    options.client.length > 0 ||
    options.skillClient.length > 0 ||
    options.skill !== undefined ||
    options.installHopper;
const doctorScope = (options) => options.client.length === 0 &&
    options.provider.length === 0 &&
    options.skill === undefined
    ? undefined
    : {
        clients: options.client,
        providers: options.provider,
        skill: options.skill === true,
    };
