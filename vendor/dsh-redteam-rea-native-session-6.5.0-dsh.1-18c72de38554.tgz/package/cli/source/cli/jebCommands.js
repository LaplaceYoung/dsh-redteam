import { z } from "incur";
import { AnalysisError } from "../../../upstream/dist/domain/analysisErrorBase.js";
import { JebAnalysisService } from "../../../upstream/dist/application/jeb/JebAnalysisService.js";
import { createJebAnalysisProvider } from "../../../upstream/dist/composition/jeb.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { logCliCommand } from "../cliLogging.js";
import { projectAnalysisError } from "../../../upstream/dist/domain/analysisErrorProjection.js";
import { withCommandCancellation } from "./commandCancellation.js";
/** Expose the same explicit JEB requests through one-shot CLI commands. */
export const registerJebCommands = (cli, logger, environment, provider = createJebAnalysisProvider(environment)) => {
    const service = new JebAnalysisService(provider);
    const execute = (name, operation, input) => withCommandCancellation((signal) => logCliCommand(logger, name, async () => {
        const result = await service.execute(operation, input, { signal });
        try {
            await provider.close();
        }
        catch (cause) {
            if (cause instanceof AnalysisError)
                return projectAnalysisError(cause);
            throw cause;
        }
        return result.ok ? result.value : projectAnalysisError(result.error);
    }));
    cli.command(CLI_COMMANDS.inspectJebClient, {
        description: "Inspect the running JEB MCP client without opening a target",
        args: z.object({}),
        run: () => execute(CLI_COMMANDS.inspectJebClient, "inspect_jeb_client", {}),
    });
    cli.command(CLI_COMMANDS.openJebProject, {
        description: "Open or create a JEB project from an artifact or .jdb2 database",
        args: z.object({
            path: z
                .string()
                .describe("Artifact or .jdb2 path resolved by the JEB engine host"),
        }),
        run: ({ args }) => execute(CLI_COMMANDS.openJebProject, "open_jeb_project", args),
    });
    cli.command(CLI_COMMANDS.listJebUnits, {
        description: "List JEB project units by path and type with optional filter",
        args: z.object({}),
        options: z.object({
            filter: z
                .string()
                .optional()
                .describe("Wildcard filter matched against unit paths"),
            "parent-unit-path": z
                .string()
                .optional()
                .describe("Restrict results to descendants of this unit path"),
            index: z
                .number()
                .int()
                .nonnegative()
                .default(0)
                .describe("Zero-based index of the first result to return"),
            count: z
                .number()
                .int()
                .min(1)
                .max(100)
                .default(100)
                .describe("Maximum results; the engine caps unit pages at 100"),
        }),
        run: ({ options }) => execute(CLI_COMMANDS.listJebUnits, "list_jeb_units", {
            index: options.index,
            count: options.count,
            ...(options.filter === undefined ? {} : { filter: options.filter }),
            ...(options["parent-unit-path"] === undefined
                ? {}
                : { parent_unit_path: options["parent-unit-path"] }),
        }),
    });
    cli.command(CLI_COMMANDS.decompileJebItem, {
        description: "Decompile one JEB type or method to engine pseudo-code",
        args: z.object({
            "item-address": z
                .string()
                .min(1)
                .describe("Type or method address within the unit"),
            "item-kind": z
                .enum(["type", "method"])
                .describe("Kind of item to decompile"),
        }),
        options: z.object({
            "unit-path": z
                .string()
                .min(1)
                .optional()
                .describe("Target code unit; the engine's first code unit when omitted"),
        }),
        run: ({ args, options }) => execute(CLI_COMMANDS.decompileJebItem, "decompile_jeb_item", {
            item_address: args["item-address"],
            item_kind: args["item-kind"],
            ...(options["unit-path"] === undefined
                ? {}
                : { unit_path: options["unit-path"] }),
        }),
    });
};
