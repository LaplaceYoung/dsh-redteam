import { z } from "incur";
import { AnalysisError } from "../../../upstream/dist/domain/analysisErrorBase.js";
import { ApktoolResourceAnalysisService } from "../../../upstream/dist/application/apktool/ApktoolResourceAnalysisService.js";
import { createApktoolResourceAnalysisProvider } from "../../../upstream/dist/composition/apktool.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { logCliCommand } from "../cliLogging.js";
import { projectAnalysisError } from "../../../upstream/dist/domain/analysisErrorProjection.js";
import { apktoolInputSchemas, } from "../../../upstream/dist/domain/apktool/apktoolResourceAnalysis.js";
import { withCommandCancellation } from "./commandCancellation.js";
/** Expose the same explicit Apktool requests through one-shot CLI commands. */
export const registerApktoolCommands = (cli, logger, environment, provider = createApktoolResourceAnalysisProvider(environment)) => {
    const service = new ApktoolResourceAnalysisService(provider);
    const execute = (name, operation, input) => withCommandCancellation((signal) => logCliCommand(logger, name, async () => {
        const result = await service.execute(operation, input, { signal });
        try {
            await provider.close();
        }
        catch (cause) {
            if (cause instanceof AnalysisError)
                return projectAnalysisError(cause);
            throw cause;
        }
        return result.ok ? result.value : projectAnalysisError(result.error);
    }));
    cli.command(CLI_COMMANDS.inspectApktoolClient, {
        description: "Inspect the caller-selected apktool launcher without decoding anything",
        args: z.object({}),
        run: () => execute(CLI_COMMANDS.inspectApktoolClient, "inspect_apktool_client", {}),
    });
    cli.command(CLI_COMMANDS.decodeAndroidResources, {
        description: "Decode one APK's manifest, metadata, and string resources with apktool",
        args: z.object({
            path: z.string().min(1).describe("Local APK file to decode"),
        }),
        // The locale grammar and the string-projection default belong to the
        // apktool input owner. Read them from that schema rather than restating a
        // narrower locale pattern, which refused the owner's own advertised
        // `b+zh+Hans+CN` form at the CLI boundary.
        options: z.object({
            locale: apktoolInputSchemas.decode_android_resources.shape.locale,
            strings: z
                .boolean()
                .default(apktoolInputSchemas.decode_android_resources.shape.include_strings.parse(undefined))
                .describe("Include string resources; use --no-strings to skip projecting them"),
        }),
        run: ({ args, options }) => execute(CLI_COMMANDS.decodeAndroidResources, "decode_android_resources", {
            path: args.path,
            include_strings: options.strings,
            ...(options.locale === undefined ? {} : { locale: options.locale }),
        }),
    });
};
