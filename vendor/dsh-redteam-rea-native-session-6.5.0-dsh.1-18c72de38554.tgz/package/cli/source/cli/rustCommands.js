import { z } from "incur";
import { resolve } from "node:path";
import { createRustBinaryService } from "../../../upstream/dist/composition/rust.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { logCliCommand } from "../cliLogging.js";
import { projectAnalysisError } from "../../../upstream/dist/domain/analysisErrorProjection.js";
import { withCommandCancellation } from "./commandCancellation.js";
/** Resolve caller paths and inspect embedded Rust dependencies through the shared workflow. */
export const registerRustCommands = (cli, logger) => {
    const service = createRustBinaryService();
    cli.command(CLI_COMMANDS.inspectRustBinary, {
        description: "Inspect an embedded cargo-auditable Rust dependency list without target execution",
        args: z.object({
            path: z.string().describe("Local ELF, PE or thin Mach-O image"),
        }),
        run: ({ args }) => withCommandCancellation((signal) => logCliCommand(logger, CLI_COMMANDS.inspectRustBinary, async () => {
            const result = await service.inspect({ path: resolve(args.path) }, { signal });
            return result.ok ? result.value : projectAnalysisError(result.error);
        })),
    });
};
