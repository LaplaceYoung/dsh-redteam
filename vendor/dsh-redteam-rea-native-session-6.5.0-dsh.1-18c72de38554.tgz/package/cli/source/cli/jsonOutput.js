import { bufferedJsonParts, jsonParts } from "../../../upstream/dist/domain/jsonSerialization.js";
/**
 * Write ordinary JSON without constructing a document-sized string.
 *
 * `json` is indented for a terminal reader. Piped or redirected output, which
 * agents and scripts consume, is compact: indentation adds no information and
 * measured 16-45% more model tokens on real results. The value is identical.
 */
export const writeJsonOutput = async (value, destination, format = "json") => {
    for (const part of bufferedJsonParts(jsonOutputParts(value, format, isTerminal(destination))))
        await writeOutputText(destination, part);
};
const isTerminal = (destination) => "isTTY" in destination && destination.isTTY === true;
export const writeOutputText = (destination, part) => new Promise((resolve, reject) => {
    const onError = (cause) => reject(cause);
    destination.once("error", onError);
    try {
        destination.write(part, (cause) => {
            if (cause) {
                // A Writable can emit its error after invoking the write callback.
                setImmediate(() => destination.off("error", onError));
                reject(cause);
            }
            else {
                destination.off("error", onError);
                resolve();
            }
        });
    }
    catch (cause) {
        destination.off("error", onError);
        reject(cause);
    }
});
/** The exact formatted document, including its final newline. */
export function* jsonOutputParts(value, format, pretty = true) {
    if (format === "jsonl" && Array.isArray(value)) {
        for (const item of value) {
            yield* jsonParts(item);
            yield "\n";
        }
        return;
    }
    yield* jsonParts(value, pretty && format === "json");
    yield "\n";
}
