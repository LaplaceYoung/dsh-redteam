import { reportProgress } from '../../context.mjs';
import { Cli, z } from "incur";
import { createWebRuntimeService } from "../../../upstream/dist/composition/webRuntime.js";
import { browserCliError } from "../cliBrowserContext.js";
import { browserScopeOptions, observationDuration, } from "../cliObservationOptions.js";
import { logCliCommand } from "../cliLogging.js";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { withCommandCancellation } from "./commandCancellation.js";
/** CLI progress exposes the actual armed point on stderr without corrupting JSON results. */
const runtimeProgress = {
    report: async (update) => {
        await reportProgress(update);
    },
};
/** Register public equivalents of the two modular website runtime tools. */
export const registerWebRuntimeCommands = (cli, logger) => {
    cli.command(CLI_COMMANDS.observeWebExecution, {
        description: "Observe precise page execution; resets counters and temporarily disables optimization",
        args: z.object({
            endpoint: z.string().describe("Existing loopback browser CDP endpoint"),
            targetId: z
                .string()
                .describe("Selected page target ID from list-browser-targets"),
        }),
        options: z.object({
            ...browserScopeOptions,
            observationMs: observationDuration(10_000, 1),
        }),
        run: ({ args, options }) => withCommandCancellation((signal) => logCliCommand(logger, "observe-web-execution", async () => {
            const result = await createWebRuntimeService().observe({
                cdp_endpoint: args.endpoint,
                target_id: args.targetId,
                allowed_origins: options.allowedOrigins,
                observation_ms: options.observationMs,
            }, { progress: runtimeProgress, signal });
            return result.ok ? result.value : browserCliError(result.error);
        })),
    });
    cli.command(CLI_COMMANDS.inspectWebEventListeners, {
        description: "Inspect native listener source locations on the first main-document CSS match",
        args: z.object({
            endpoint: z.string().describe("Existing loopback browser CDP endpoint"),
            targetId: z
                .string()
                .describe("Selected page target ID from list-browser-targets"),
            selector: z
                .string()
                .describe("Native CSS selector; inspect the first main-document match"),
        }),
        options: z.object({ ...browserScopeOptions }),
        run: ({ args, options }) => withCommandCancellation((signal) => logCliCommand(logger, "inspect-web-event-listeners", async () => {
            const result = await createWebRuntimeService().inspect({
                cdp_endpoint: args.endpoint,
                target_id: args.targetId,
                selector: args.selector,
                allowed_origins: options.allowedOrigins,
            }, { signal });
            return result.ok ? result.value : browserCliError(result.error);
        })),
    });
};
