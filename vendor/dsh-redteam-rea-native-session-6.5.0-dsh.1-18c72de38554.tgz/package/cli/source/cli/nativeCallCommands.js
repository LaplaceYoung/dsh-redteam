import { z } from "incur";
import { CLI_COMMANDS } from "../cliCommandNames.js";
import { parseCliJsonInput } from "../cliJsonInput.js";
import { logCliCommand } from "../cliLogging.js";
import { projectAnalysisError } from "../../../upstream/dist/domain/analysisErrorProjection.js";
import { analysisInputErrorFromIssues } from "../../../upstream/dist/domain/inputIssueProjection.js";
import { jsonValueSchema } from "../../../upstream/dist/domain/jsonValue.js";
import { nativeCallObservationInputSchema } from "../../../upstream/dist/domain/native/nativeCallObservation.js";
const OPERATION = "observe_native_calls";
/** `observe-native-calls <path> <input-json>`: the MCP input object as JSON. */
export const registerNativeCallCommands = (cli, logger, runProviderAnalysis) => {
    cli.command(CLI_COMMANDS.observeNativeCalls, {
        description: "Launch a Mach-O under LLDB and record entries into selected functions or Objective-C methods",
        args: z.object({
            path: z.string().describe("Mach-O or app path"),
            inputJson: z
                .string()
                .describe("Inline JSON or a JSON file path: breakpoints, arguments, environment, duration_ms, max_events, argument_registers, backtrace_frames"),
        }),
        run: ({ args }) => logCliCommand(logger, CLI_COMMANDS.observeNativeCalls, async () => {
            const input = await parseCliJsonInput(args.inputJson, OPERATION);
            if (!input.ok)
                return input.error;
            const parsed = nativeCallObservationInputSchema.safeParse(input.value);
            if (!parsed.success)
                return {
                    error: "Analysis failed",
                    ...projectAnalysisError(analysisInputErrorFromIssues(OPERATION, parsed.error.issues, input.value)),
                };
            return runProviderAnalysis(args.path, OPERATION, z.record(z.string(), jsonValueSchema).parse(parsed.data), logger);
        }),
    });
};
