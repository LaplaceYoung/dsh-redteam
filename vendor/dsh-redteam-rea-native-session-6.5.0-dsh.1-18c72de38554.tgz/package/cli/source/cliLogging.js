import { markFailure } from '../context.mjs';
import { analysisCliErrorEnvelopeSchema, analysisErrorProjectionSchema, } from "../../upstream/dist/contracts/errorSchemas.js";
import { AnalysisError } from "../../upstream/dist/domain/analysisErrorBase.js";
import { projectAnalysisError, } from "../../upstream/dist/domain/analysisErrorProjection.js";
const isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
const loggedFailures = new WeakMap();
/** Return the canonical failure projection owned by the CLI result boundary. */
const projectCliOperationFailure = (value) => {
    if (!isRecord(value))
        return undefined;
    const direct = analysisErrorProjectionSchema.safeParse(value);
    if (direct.success)
        return value;
    const envelope = analysisCliErrorEnvelopeSchema.safeParse(value);
    if (envelope.success) {
        const { error: _label, input_path: inputPath, input_reason: inputReason, ...projection } = value;
        const parsed = projection;
        if (typeof inputPath !== "string" && typeof inputReason !== "string")
            return parsed;
        return {
            ...parsed,
            details: {
                ...parsed.details,
                ...(typeof inputPath === "string" ? { input_path: inputPath } : {}),
                ...(typeof inputReason === "string"
                    ? { input_reason: inputReason }
                    : {}),
            },
        };
    }
    if (isRecord(value.error)) {
        const nested = analysisErrorProjectionSchema.safeParse(value.error);
        if (nested.success)
            return value.error;
    }
    return undefined;
};
/** Return the canonical projection or original record classified as failed. */
const inferCliOperationFailure = (value) => {
    const projection = projectCliOperationFailure(value);
    if (projection !== undefined)
        return projection;
    if (isRecord(value) && value.healthy === false)
        return value;
    return undefined;
};
export const cliOperationFailurePayload = (value) => {
    if (isRecord(value) && loggedFailures.has(value))
        return loggedFailures.get(value);
    return inferCliOperationFailure(value);
};
/** Identify caller-visible CLI outcomes that mean the requested operation failed. */
export const isCliOperationFailure = (value) => cliOperationFailurePayload(value) !== undefined;
/** Log one CLI command with duration and a stable success or failure status. */
export const logCliCommand = async (logger, command, execute, isCommandFailure) => {
    const startedAt = performance.now();
    try {
        const value = await execute();
        const inferredFailure = inferCliOperationFailure(value);
        const failed = isCommandFailure?.(value) ?? inferredFailure !== undefined;
        if (isRecord(value))
            loggedFailures.set(value, failed ? (inferredFailure ?? value) : undefined);
        logger[failed ? "error" : "info"]({
            command,
            durationMs: Math.round((performance.now() - startedAt) * 100) / 100,
            status: failed ? "error" : "ok",
        }, failed ? "CLI command failed" : "CLI command completed");
        if (failed)
            markFailure();
        return value;
    }
    catch (cause) {
        markFailure();
        logger.error({
            command,
            durationMs: Math.round((performance.now() - startedAt) * 100) / 100,
            status: "error",
        }, "CLI command failed");
        if (cause instanceof AnalysisError) {
            markFailure();
            return projectAnalysisError(cause);
        }
        throw cause;
    }
};
